import socket
import json
import board
import busio
from adafruit_seesaw.seesaw import Seesaw
import adafruit_sht31d
import adafruit_ads1x15.ads1015 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

# --- CONFIGURATION ---
HOST = ''  # Bind to all available interfaces
PORT = 5000

# --- SENSOR INITIALIZATION ---
i2c = busio.I2C(board.SCL, board.SDA)

try:
    sht = adafruit_sht31d.SHT31D(i2c)
except Exception as e:
    print("[!] SHT31D init error:", e)
    sht = None

try:
    soil = Seesaw(i2c, addr=0x36)
except Exception as e:
    print("[!] Soil sensor init error:", e)
    soil = None

try:
    ads = ADS.ADS1015(i2c)
    wind_channel = AnalogIn(ads, ADS.P0)
except Exception as e:
    print("[!] ADS1015 init error:", e)
    wind_channel = None

# --- UTILITY FUNCTIONS ---
def map_range(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def get_sensor_data():
    data = {}

    try:
        data["temperature"] = round(sht.temperature, 2) if sht else None
        data["humidity"] = round(sht.relative_humidity, 2) if sht else None
    except Exception as e:
        print("[!] Temp/Humidity read error:", e)
        data["temperature"] = None
        data["humidity"] = None

    try:
        data["soil"] = float(soil.moisture_read()) if soil else None
    except Exception as e:
        print("[!] Soil read error:", e)
        data["soil"] = None

    try:
        if wind_channel:
            voltage = wind_channel.voltage
            data["wind"] = round(map_range(voltage, 0.4, 2.0, 0, 32), 2)
        else:
            data["wind"] = None
    except Exception as e:
        print("[!] Wind read error:", e)
        data["wind"] = None

    return data

def handle_connection(conn, addr):
    print(f"Connected by {addr}")
    try:
        message = conn.recv(1024).decode()
        if message == "Requesting data":
            data = get_sensor_data()
            response = json.dumps(data).encode()
            conn.sendall(response)
        else:
            print("Unexpected message received:", message)
    except Exception as e:
        print(f"[!] Communication error: {e}")
    finally:
        conn.close()

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"Secondary Pi listening on port {PORT}...")

        while True:
            conn, addr = s.accept()
            handle_connection(conn, addr)

if __name__ == "__main__":
    main()

