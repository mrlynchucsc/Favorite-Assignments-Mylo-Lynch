import socket
import json
import time
import datetime
import mysql.connector
import matplotlib.pyplot as plt

import board
import busio
from adafruit_seesaw.seesaw import Seesaw
import adafruit_sht31d
import adafruit_ads1x15.ads1015 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

# --- CONFIGURATION ---
SECONDARY_PIS = [
    ("192.168.0.101", 5000),
    ("192.168.0.172", 5000)
]
TIMEOUT = 5
POLL_INTERVAL = 10  # seconds between polling rounds

DB_HOST = "192.168.0.142"  # IP of the laptop/PC running XAMPP
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "piSenseDB"

# --- SENSOR INITIALIZATION ---
i2c = busio.I2C(board.SCL, board.SDA)

try:
    sht = adafruit_sht31d.SHT31D(i2c)
except Exception as e:
    print("[!] SHT31D init error:", e)
    sht = None

try:
    soil = Seesaw(i2c, addr=0x36)
except Exception as e:
    print("[!] Soil sensor init error:", e)
    soil = None

try:
    ads = ADS.ADS1015(i2c)
    wind_channel = AnalogIn(ads, ADS.P0)
except Exception as e:
    print("[!] ADS1015 init error:", e)
    wind_channel = None

# --- UTILITY FUNCTIONS ---
def map_range(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def get_sensor_data():
    data = {}
    try:
        data["temperature"] = round(sht.temperature, 2) if sht else None
        data["humidity"] = round(sht.relative_humidity, 2) if sht else None
    except Exception as e:
        print("[!] SHT31D read error:", e)
        data["temperature"] = None
        data["humidity"] = None

    try:
        data["soil"] = float(soil.moisture_read()) if soil else None
    except Exception as e:
        print("[!] Soil read error:", e)
        data["soil"] = None

    try:
        if wind_channel:
            voltage = wind_channel.voltage
            data["wind"] = round(map_range(voltage, 0.4, 2.0, 0, 32), 2)
        else:
            data["wind"] = None
    except Exception as e:
        print("[!] Wind sensor read error:", e)
        data["wind"] = None

    return data

def request_data(ip, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(TIMEOUT)
            sock.connect((ip, port))
            sock.sendall(b"Requesting data")
            received = sock.recv(1024)
            return json.loads(received.decode())
    except socket.timeout:
        print(f"[!] Timeout while connecting to {ip}")
    except Exception as e:
        print(f"[!] Error communicating with {ip}: {e}")
    return None

def insert_data(table, data, timestamp):
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cursor = conn.cursor()
        sql = f"""
            INSERT INTO {table} (timestamp, temperature, humidity, wind_speed, soil_moisture)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (
            timestamp,
            data.get("temperature"),
            data.get("humidity"),
            data.get("wind"),
            data.get("soil")
        ))
        conn.commit()
        cursor.close()
        conn.close()
        print(f"[+] Inserted data into {table}")
    except Exception as e:
        print(f"[!] MySQL insert error: {e}")

def main():
    round_num = 1
    while True:
        print(f"\n--- Polling Round {round_num} ---")
        timestamp = datetime.datetime.now()
        all_data = []

        # Primary Pi data
        primary_data = get_sensor_data()
        all_data.append(primary_data)
        insert_data("sensor_readings1", primary_data, timestamp)

        # Secondary Pis
        for i, (ip, port) in enumerate(SECONDARY_PIS):
            data = request_data(ip, port)
            if data is not None:
                all_data.append(data)
                insert_data(f"sensor_readings{i+2}", data, timestamp)
            else:
                all_data.append({
                    "temperature": None,
                    "humidity": None,
                    "soil": None,
                    "wind": None,
                    "missing": True
                })

        round_num += 1
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main()

