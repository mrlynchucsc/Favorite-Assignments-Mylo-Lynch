import socket
import threading
import json
import time
import board
import busio
import datetime
import mysql.connector

from adafruit_seesaw.seesaw import Seesaw
import adafruit_sht31d
import adafruit_ads1x15.ads1015 as ADS
from adafruit_ads1x15.analog_in import AnalogIn
# [Same imports and sensor init up to config]
# --- CONFIGURATION ---
PI_ID = 1
LISTEN_PORT = 5001
ACK_PORT = 5002
PI_IPS = {
    1: "192.168.0.144",
    2: "192.168.0.101",
    3: "192.168.0.172"
}
ROUND_LIMIT = 100
TOKEN_INTERVAL = 10
TIMEOUT = 5

# DB Config
DB_HOST = "192.168.0.142"
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "piSenseDB"

round_count = 0
ack_event = threading.Event()
expected_ack_ip = None

# [Same sensor functions and DB insert]
# --- SENSOR INITIALIZATION ---
i2c = busio.I2C(board.SCL, board.SDA)

try:
    sht = adafruit_sht31d.SHT31D(i2c)
except Exception as e:
    print("[!] SHT31D init error:", e)
    sht = None

try:
    soil = Seesaw(i2c, addr=0x36)
except Exception as e:
    print("[!] Soil sensor init error:", e)
    soil = None

try:
    ads = ADS.ADS1015(i2c)
    wind_channel = AnalogIn(ads, ADS.P0)
except Exception as e:
    print("[!] ADS1015 init error:", e)
    wind_channel = None

# --- HELPERS ---
def map_range(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def get_sensor_data():
    data = {"id": PI_ID}
    try:
        data["temperature"] = round(sht.temperature, 2) if sht else None
        data["humidity"] = round(sht.relative_humidity, 2) if sht else None
    except Exception:
        data["temperature"] = None
        data["humidity"] = None

    try:
        data["soil"] = float(soil.moisture_read()) if soil else None
    except Exception:
        data["soil"] = None

    try:
        if wind_channel:
            voltage = wind_channel.voltage
            data["wind"] = round(map_range(voltage, 0.4, 2.0, 0, 32), 2)
        else:
            data["wind"] = None
    except Exception:
        data["wind"] = None

    return data
def insert_data_to_db(sensor_data, timestamp):
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cursor = conn.cursor()
        for entry in sensor_data:
            table = f"sensor_readings{entry['id']}"
            cursor.execute(f"""
                INSERT INTO {table} (timestamp, temperature, humidity, wind_speed, soil_moisture)
                VALUES (%s, %s, %s, %s, %s)
            """, (
                timestamp,
                entry.get("temperature"),
                entry.get("humidity"),
                entry.get("wind"),
                entry.get("soil")
            ))
        conn.commit()
        cursor.close()
        conn.close()
        print("[+] [DEBUG] Pi 1: Inserted data to DB.")
    except Exception as e:
        print(f"[!] [DEBUG] Pi 1: MySQL insert error: {e}")
        
def send_and_wait_ack(token, target_ip):
    global expected_ack_ip
    expected_ack_ip = target_ip
    ack_event.clear()

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((target_ip, LISTEN_PORT))
            sock.sendall(json.dumps(token).encode())
            print(f"[DEBUG] Pi 1: Sent token to {target_ip}, waiting for ACK...")

        if ack_event.wait(timeout=TIMEOUT):
            print(f"[INFO] Pi 1: ACK received from {target_ip}")
            return True
        else:
            print(f"[WARN] Pi 1: Timeout waiting for ACK from {target_ip}")
    except Exception as e:
        print(f"[ERROR] Pi 1: Error sending to {target_ip}: {e}")
    return False

def send_ack(ip):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((ip, ACK_PORT))
            sock.sendall(b"ACK")
            print(f"[DEBUG] Pi 1: Sent ACK to {ip}")
    except:
        print(f"[WARN] Pi 1: Failed to send ACK to {ip}")

def start_new_round():
    global round_count
    round_count += 1
    print(f"[INFO] Pi 1: Starting round {round_count}")
    time.sleep(TOKEN_INTERVAL)

    token = {
        "type": "token",
        "origin": PI_ID,
        "data": [get_sensor_data()]
    }

    for target_id in [2, 3]:
        print(f"[DEBUG] Pi 1: Trying to send token to Pi {target_id}")
        if send_and_wait_ack(token, PI_IPS[target_id]):
            print(f"[INFO] Pi 1: Token sent successfully to Pi {target_id}")
            return

    print("[WARN] Pi 1: No Pis responded. Writing own data to DB.")
    timestamp = datetime.datetime.now()
    insert_data_to_db(token["data"], timestamp)
    start_new_round()

def handle_reset(token, sender_ip):
    print(f"[DEBUG] Pi 1: Received RESET token from {sender_ip}")
    send_ack(sender_ip)
    start_new_round()

def token_receiver():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind(('', LISTEN_PORT))
        server.listen()
        print(f"[INFO] Pi 1: Listening for tokens on port {LISTEN_PORT}...")
        while True:
            conn, addr = server.accept()
            with conn:
                try:
                    data = conn.recv(4096)
                    if data in [b"ACK", b"ping"]:
                        print(f"[DEBUG] Pi 1: Received {data.decode()} from {addr[0]} (on token port)")
                        return

                    token = json.loads(data.decode())
                    msg_type = token.get("type", "")

                    if msg_type == "reset":
                        handle_reset(token, addr[0])
                        continue

                    print(f"[DEBUG] Pi 1: Unexpected token type from {addr[0]}: {msg_type}")
                except Exception as e:
                    print(f"[ERROR] Pi 1: Token receiver error: {e}")

def ack_receiver():
    global ack_event
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind(('', ACK_PORT))
        server.listen()
        print(f"[INFO] Pi 1: Listening for ACKs on port {ACK_PORT}...")
        while True:
            conn, addr = server.accept()
            with conn:
                try:
                    data = conn.recv(1024)
                    if data == b"ACK":
                        print(f"[DEBUG] Pi 1: Got ACK from {addr[0]} on ACK port")
                        if addr[0] == expected_ack_ip:
                            ack_event.set()
                except:
                    pass

def main():
    print("[BOOT] Pi 1 is booting up and initializing receiver threads.")
    threading.Thread(target=token_receiver, daemon=True).start()
    threading.Thread(target=ack_receiver, daemon=True).start()
    time.sleep(2)
    print("[INFO] Pi 1: Starting first round.")
    start_new_round()
    while round_count < ROUND_LIMIT:
        time.sleep(1)

if __name__ == "__main__":
    main()

