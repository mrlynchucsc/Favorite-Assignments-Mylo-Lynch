import socket
import threading
import json
import time
import board
import busio
import datetime
import mysql.connector

from adafruit_seesaw.seesaw import Seesaw
import adafruit_sht31d
import adafruit_ads1x15.ads1015 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

# --- CONFIGURATION ---
PI_ID = 2
LISTEN_PORT = 5001
ACK_PORT = 5002
PI_IPS = {
    1: "192.168.0.144",
    2: "192.168.0.101",
    3: "192.168.0.172"
}
ROUND_LIMIT = 100
TOKEN_INTERVAL = 10
TIMEOUT = 5

# DB Config
DB_HOST = "192.168.0.142"
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "piSenseDB"

round_count = 0
ack_event = threading.Event()
expected_ack_ip = None

# --- SENSOR INITIALIZATION ---
i2c = busio.I2C(board.SCL, board.SDA)

try:
    sht = adafruit_sht31d.SHT31D(i2c)
except Exception as e:
    print("[!] SHT31D init error:", e)
    sht = None

try:
    soil = Seesaw(i2c, addr=0x36)
except Exception as e:
    print("[!] Soil sensor init error:", e)
    soil = None

try:
    ads = ADS.ADS1015(i2c)
    wind_channel = AnalogIn(ads, ADS.P0)
except Exception as e:
    print("[!] ADS1015 init error:", e)
    wind_channel = None

# --- HELPERS ---
def map_range(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def get_sensor_data():
    data = {"id": PI_ID}
    try:
        data["temperature"] = round(sht.temperature, 2) if sht else None
        data["humidity"] = round(sht.relative_humidity, 2) if sht else None
    except Exception:
        data["temperature"] = None
        data["humidity"] = None

    try:
        data["soil"] = float(soil.moisture_read()) if soil else None
    except Exception:
        data["soil"] = None

    try:
        if wind_channel:
            voltage = wind_channel.voltage
            data["wind"] = round(map_range(voltage, 0.4, 2.0, 0, 32), 2)
        else:
            data["wind"] = None
    except Exception:
        data["wind"] = None

    return data

def insert_data_to_db(sensor_data, timestamp):
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cursor = conn.cursor()
        for entry in sensor_data:
            table = f"sensor_readings{entry['id']}"
            cursor.execute(f"""
                INSERT INTO {table} (timestamp, temperature, humidity, wind_speed, soil_moisture)
                VALUES (%s, %s, %s, %s, %s)
            """, (
                timestamp,
                entry.get("temperature"),
                entry.get("humidity"),
                entry.get("wind"),
                entry.get("soil")
            ))
        conn.commit()
        cursor.close()
        conn.close()
        print("[+] [DEBUG] Pi 2: Inserted data to DB.")
    except Exception as e:
        print(f"[!] [DEBUG] Pi 2: MySQL insert error: {e}")
def send_and_wait_ack(token, target_ip):
    global expected_ack_ip
    expected_ack_ip = target_ip
    ack_event.clear()

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((target_ip, LISTEN_PORT))
            sock.sendall(json.dumps(token).encode())
            print(f"[DEBUG] Pi 2: Sent token to {target_ip}, waiting for ACK...")

        if ack_event.wait(timeout=TIMEOUT):
            print(f"[INFO] Pi 2: ACK received from {target_ip}")
            return True
        else:
            print(f"[WARN] Pi 2: Timeout waiting for ACK from {target_ip}")
    except Exception as e:
        print(f"[ERROR] Pi 2: Failed to send token to {target_ip}: {e}")

    return False

def send_ack(ip):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((ip, ACK_PORT))
            sock.sendall(b"ACK")
            print(f"[DEBUG] Pi 2: Sent ACK to {ip}")
    except:
        print(f"[WARN] Pi 2: Failed to send ACK to {ip}")

def send_reset(fallback_targets):
    reset_token = {
        "type": "reset",
        "sender": PI_ID
    }
    for target in fallback_targets:
        print(f"[DEBUG] Pi 2: Sending RESET to Pi {target}")
        if send_and_wait_ack(reset_token, PI_IPS[target]):
            print(f"[INFO] Pi 2: Reset ACK received from Pi {target}")
            return
    print("[WARN] Pi 2: No reset ACKs. Starting new round.")
    start_new_round()

def start_new_round():
    global round_count
    round_count += 1
    print(f"[INFO] Pi 2: Starting fallback round {round_count}")
    time.sleep(TOKEN_INTERVAL)
    token = {
        "type": "token",
        "origin": PI_ID,
        "data": [get_sensor_data()]
    }
    for target_id in [3, 1]:
        print(f"[DEBUG] Pi 2: Trying to send token to Pi {target_id}")
        if send_and_wait_ack(token, PI_IPS[target_id]):
            print(f"[DEBUG] Pi 2: Token sent to Pi {target_id}")
            return
    print("[WARN] Pi 2: No Pis responded. Writing to DB.")
    timestamp = datetime.datetime.now()
    insert_data_to_db(token["data"], timestamp)
    start_new_round()

def handle_reset(token, sender_ip):
    print(f"[INFO] Pi 2: Processing RESET from {sender_ip}, forwarding to Pi 1")
    send_ack(sender_ip)
    if send_and_wait_ack(token, PI_IPS[1]):
        print("[INFO] Pi 2: Reset forwarded to Pi 1")
    else:
        print("[WARN] Pi 1 didn’t ACK reset. Pi 2 starting new round.")
        start_new_round()

def handle_data_token(token, sender_ip):
    token["data"].append(get_sensor_data())
    print(f"[INFO] Pi 2: Appended data, trying to forward token to Pi 3...")
    if send_and_wait_ack(token, PI_IPS[3]):
        print("[INFO] Pi 2: Token sent to Pi 3.")
    else:
        print("[WARN] Pi 3 unresponsive. Pi 2 writing to DB.")
        timestamp = datetime.datetime.now()
        insert_data_to_db(token["data"], timestamp)
        send_reset([1])

def token_receiver():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind(('', LISTEN_PORT))
        server.listen()
        print(f"[INFO] Pi 2: Listening for tokens on port {LISTEN_PORT}...")
        while True:
            conn, addr = server.accept()
            with conn:
                try:
                    raw = conn.recv(4096)

                    if raw in [b"ACK", b"ping"]:
                        print(f"[DEBUG] Pi 2: Received {raw.decode()} from {addr[0]}")
                        return

                    token = json.loads(raw.decode())
                    msg_type = token.get("type", "")

                    if msg_type == "reset":
                        print(f"[DEBUG] Pi 2: Received RESET token from {addr[0]}")
                        handle_reset(token, addr[0])
                        return

                    if msg_type == "token":
                        if addr[0] != PI_IPS[1] and token.get("origin") != PI_ID:
                            print(f"[WARN] Pi 2: Ignoring token from {addr[0]} (unexpected sender)")
                            return

                        print(f"[DEBUG] Pi 2: Received DATA token from {addr[0]}")
                        send_ack(addr[0])
                        handle_data_token(token, addr[0])
                        continue

                    print(f"[WARN] Pi 2: Unknown token type: {msg_type}")
                except Exception as e:
                    print(f"[ERROR] Pi 2: Failed to process token: {e}")

def ack_receiver():
    global ack_event
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind(('', ACK_PORT))
        server.listen()
        print(f"[INFO] Pi 2: Listening for ACKs on port {ACK_PORT}...")
        while True:
            conn, addr = server.accept()
            with conn:
                try:
                    data = conn.recv(1024)
                    if data == b"ACK":
                        print(f"[DEBUG] Pi 2: Got ACK from {addr[0]} on ACK port")
                        if addr[0] == expected_ack_ip:
                            ack_event.set()
                except:
                    pass

def main():
    print("[BOOT] Pi 2 is booting and listening...")
    threading.Thread(target=token_receiver, daemon=True).start()
    threading.Thread(target=ack_receiver, daemon=True).start()
    while round_count < ROUND_LIMIT:
        time.sleep(1)

if __name__ == "__main__":
    main()
