from flask import Flask, render_template_string
import mysql.connector

# Set matplotlib to use non-GUI backend BEFORE importing pyplot
import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from datetime import datetime, timezone
import os
import requests

# --- CONFIGURATION ---
DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "piSenseDB"
OPEN_METEO_LAT = 36.9741  # Santa Cruz, CA
OPEN_METEO_LON = -122.0308

app = Flask(__name__)
os.makedirs("static", exist_ok=True)

# --- HTML TEMPLATE ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>piSense Dashboard</title>
</head>
<body>
    <h1>Sensor Data Dashboard</h1>
    <h3>Temperature</h3><img src="/static/temperature.png">
    <h3>Humidity</h3><img src="/static/humidity.png">
    <h3>Wind Speed</h3><img src="/static/wind.png">
    <h3>Soil Moisture</h3><img src="/static/soil.png">
</body>
</html>
"""

def fetch_forecast():
    try:
        url = (
            f"https://api.open-meteo.com/v1/forecast?latitude={OPEN_METEO_LAT}&longitude={OPEN_METEO_LON}"
            f"&hourly=temperature_2m,relative_humidity_2m,windspeed_10m"
        )
        resp = requests.get(url)
        data = resp.json()
        forecast = {}
        for i in range(len(data["hourly"]["time"])):
            ts = datetime.fromisoformat(data["hourly"]["time"][i]).replace(tzinfo=timezone.utc)
            forecast[ts.replace(minute=0, second=0, microsecond=0)] = {
                "temperature": data["hourly"]["temperature_2m"][i],
                "humidity": data["hourly"]["relative_humidity_2m"][i],
                "wind": data["hourly"]["windspeed_10m"][i]
            }
        return forecast
    except Exception as e:
        print("[!] Forecast error:", e)
        return {}

def fetch_sensor_data():
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cursor = conn.cursor(dictionary=True)
        data = {1: [], 2: [], 3: []}

        for i in range(1, 4):
            cursor.execute(f"SELECT * FROM sensor_readings{i} ORDER BY timestamp")
            data[i] = cursor.fetchall()

        cursor.close()
        conn.close()
        return data
    except Exception as e:
        print("[!] DB fetch error:", e)
        return {1: [], 2: [], 3: []}

def generate_graphs():
    data = fetch_sensor_data()
    forecast = fetch_forecast()

    timestamps = []
    averages = {"temperature": [], "humidity": [], "wind": [], "soil": []}
    pis = {1: {}, 2: {}, 3: {}}
    forecast_values = {"temperature": [], "humidity": [], "wind": []}

    for pid in [1, 2, 3]:
        pis[pid]["temperature"] = []
        pis[pid]["humidity"] = []
        pis[pid]["wind"] = []
        pis[pid]["soil"] = []
        pis[pid]["timestamps"] = []

    for i in range(len(data[1])):
        try:
            t1 = data[1][i]
            t2 = data[2][i] if i < len(data[2]) else {}
            t3 = data[3][i] if i < len(data[3]) else {}

            ts = t1["timestamp"]
            timestamps.append(ts)

            sensors = [t1, t2, t3]
            temps = []
            hums = []
            winds = []
            soils = []

            for idx, t in enumerate(sensors, start=1):
                pis[idx]["timestamps"].append(t.get("timestamp", ts))
                pis[idx]["temperature"].append(t.get("temperature"))
                pis[idx]["humidity"].append(t.get("humidity"))
                pis[idx]["wind"].append(t.get("wind_speed"))
                pis[idx]["soil"].append(t.get("soil_moisture"))

                if t.get("temperature") is not None:
                    temps.append(t["temperature"])
                if t.get("humidity") is not None:
                    hums.append(t["humidity"])
                if t.get("wind_speed") is not None:
                    winds.append(t["wind_speed"])
                if t.get("soil_moisture") is not None:
                    soils.append(t["soil_moisture"])

            averages["temperature"].append(sum(temps)/len(temps) if temps else None)
            averages["humidity"].append(sum(hums)/len(hums) if hums else None)
            averages["wind"].append(sum(winds)/len(winds) if winds else None)
            averages["soil"].append(sum(soils)/len(soils) if soils else None)

            ts_utc = ts.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
            f = forecast.get(ts_utc)
            for k in ["temperature", "humidity", "wind"]:
                forecast_values[k].append(f[k] if f else None)
        except Exception as e:
            print(f"[!] Error processing row {i}:", e)

    def plot_metric(metric, ylabel):
        plt.figure()
        for pid in [1, 2, 3]:
            plt.plot(pis[pid]["timestamps"], pis[pid][metric], label=f"Pi {pid}", marker='.')
        plt.plot(timestamps, averages[metric], label="Average", marker='o', linewidth=2)

        if metric in forecast_values:
            plt.plot(timestamps, forecast_values[metric], label="Forecast", linestyle='--', marker='x')
        plt.xlabel("Time")
        plt.ylabel(ylabel)
        plt.title(ylabel)
        plt.legend()
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(f"static/{metric}.png")
        plt.close()

    plot_metric("temperature", "Temperature (°C)")
    plot_metric("humidity", "Humidity (%)")
    plot_metric("wind", "Wind Speed (km/h)")
    plot_metric("soil", "Soil Moisture (units)")

@app.route("/")
def index():
    generate_graphs()
    return render_template_string(HTML_TEMPLATE)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)